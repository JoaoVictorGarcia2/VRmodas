import './carrinho.css';
function Carrinho() {
    return (
        <div className='carrinho'>
            <h2>Carrinho:</h2>
        </div>
    )
}

export default Carrinho;